#!/bin/bash

convert -resize 75x75 -quality 100 $1 $1

