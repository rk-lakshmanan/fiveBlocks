package com.ardublock.core.exception;

public class ArdublockStartupException extends ArdublockException
{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8794112056158752322L;

}
