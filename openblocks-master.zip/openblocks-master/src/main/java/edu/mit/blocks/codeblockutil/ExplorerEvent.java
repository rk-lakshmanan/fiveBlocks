package edu.mit.blocks.codeblockutil;

public interface ExplorerEvent {

    public int getEventType();

    public Explorer getSource();
}
