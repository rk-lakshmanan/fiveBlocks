package edu.mit.blocks.codeblockutil;

import java.awt.BorderLayout;
import java.awt.Dimension;

import javax.swing.JPanel;

public class CWheelItem extends JPanel {

    private static final long serialVersionUID = 328149080241L;

    public CWheelItem() {
        super(new BorderLayout());
        this.setPreferredSize(new Dimension(100, 100));
    }
}
